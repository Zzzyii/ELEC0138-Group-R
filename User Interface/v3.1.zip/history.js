document.addEventListener('DOMContentLoaded', function() {
    // 获取并显示历史记录
    chrome.storage.local.get(null, function(items) {
        var urlsTable = document.getElementById('urlsTable');

        for (var key in items) {
            let [url, message, time] = key.split('|'); // 假设您保存的键格式为"URL|Message|Time"
            var row = urlsTable.insertRow(-1);
            var cell1 = row.insertCell(0);
            var cell2 = row.insertCell(1);
            var cell3 = row.insertCell(2);

            cell1.textContent = url;
            cell2.textContent = message;
            cell3.textContent = time;

            if (message === "Phishing") {
                cell2.classList.add("phishing");
            }
        }
    });

    // 处理清除历史记录的按钮点击事件
    document.getElementById('clearHistory').addEventListener('click', function() {
        chrome.storage.local.clear(function() {
            console.log('All history cleared');
            // 刷新页面或清除表格内容来反映清除操作
            window.location.reload();
        });
    });
});
