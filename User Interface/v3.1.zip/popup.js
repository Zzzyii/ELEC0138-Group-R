document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('viewHistoryBtn').addEventListener('click', function() {
        chrome.tabs.create({url: 'history.html'});
    });

// 获取当前活跃标签页
chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    var currentTab = tabs[0];
    if (currentTab) {
        chrome.storage.local.get(null, function(items) {
            let found = false;
            for (let key in items) {
                // 格式为 "URL|Message|Time"
                let parts = key.split('|');
                let url = parts[0];
                let message = parts[1];
                let time = parts[2];
                if (url === currentTab.url) {
                    document.getElementById('savedMessageDisplay').textContent = `${url} is ${message} website`;
                    found = true;
                    break; 
                }
            }
            if (!found) {
                document.getElementById('savedMessageDisplay').textContent = 'Wating...';
            }
        });
    }
});

    // 检查服务器状态
    fetch('http://localhost:5000/status')
    .then(response => {
        if (response.ok) {
            return response.json();
        }
        throw new Error('Network response was not ok.');
    })
    .then(data => {
        if (data.status === 'ok') {
            document.getElementById('server-status').textContent = 'Local Machine Learning Services Online';
        } else {
            document.getElementById('server-status').textContent = 'Local Machine Learning Services error';
        }
    })
    .catch((error) => {
        console.error('Error:', error);
        document.getElementById('server-status').textContent = 'Unable to connect to local machine learning services';
    });
});
