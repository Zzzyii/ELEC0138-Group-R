function showNotification(url,message) {
    chrome.notifications.create('', {
        type: 'basic',
        iconUrl: 'images/icon48.png', 
        title: 'Anti-Phishing Checke', 
        message: `${url} is ${message} website.`
    }, function(notificationId) {
        console.log('Notification shown with id:', notificationId);
        //chrome.storage.local.set({'savedMessage': message}, function() {
        //    console.log('Message saved.');
        //});
    });
}
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    if (changeInfo.url && !changeInfo.url.startsWith('chrome')) {
        console.log("Visited: " + changeInfo.url);
      
      // 构造请求发送到Python服务器
      fetch('http://localhost:5000/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({domain: changeInfo.url}),
      })
      .then(response => response.json())
      .then(data => {
        console.log(data);

        // 构造要存储的对象
        var visitTime = new Date().toLocaleString(); // 获取当前时间
        var key = `${changeInfo.url}|${data.message}|${visitTime}`; // 构建键
        chrome.storage.local.set({[key]: data.message}, function() {
            console.log('Detection result saved with time');
        });

        if (data.message === "Phishing") {
        showNotification(changeInfo.url, data.message); 
        }
      })
      .catch((error) => {
        console.error('Error:', error);
      })
    }
  });